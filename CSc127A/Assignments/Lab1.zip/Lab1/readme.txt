I had no problems completing this lab. The directions were very straightforward and I was able to complete it quickly.
