I had no problems completeing this lab.

Everything works as expected.