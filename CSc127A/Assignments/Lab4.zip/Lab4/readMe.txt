I had no problems completeing this lab. There was a lot of intricate array work, though.

Everything works as expected.